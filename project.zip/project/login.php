
<?php 
include("connection.php");
if(!empty($_SESSION["id"])){
  session_destroy();
}
if(isset($_POST['logins'])){
  
  $Username = $_POST['Username'];
  $Password = $_POST['Password']; 
  

  if(!empty($_POST['Username'])){
    $duplicate = mysqli_query($conn, "SELECT * FROM arigatu WHERE user = '$Username'");
    $user_data = mysqli_fetch_assoc($duplicate);
    if((mysqli_num_rows($duplicate) > 0 )){
      if($user_data['pass'] == $Password ){

        $_SESSION["login"] = true;
        $_SESSION["id"] = $user_data["id"];
        header ("location: index.php");

      }else{
        echo "<script> alert('Wrong Password'); </script>";
      }
    }else{
      echo "<script> alert('Username Invalid'); </script>";
    }

  }

}

?>

<!DOCTYPE html>
<html>
    <head>
<link rel="stylesheet" href="style.css">

    </head>
    <body>
    <div class="center">
    
        <form method="post" class>
        <h1>Login</h1>
            <div class="txt_field">
                <input type="text" name="Username" required>
                <label>Username or Email</label>
            </div>
            <div class="txt_field">
                <input type="password" name="Password" required>
                <label for="">Password</label>
            </div>

            <input type="submit" value="Login" name="logins">
            <div class="signup_link">
                Not a member? <a href="reg.php">Register</a>
            </div>
        </form>
    </div>
    </body>
</html>
