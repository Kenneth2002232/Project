
<?php 
include("connection.php");

if(isset($_POST['reg'])){

    $Name = $_POST['Name'];
    $Surname = $_POST['Surname'];
    $Username = $_POST['Username'];
    $Password = $_POST['Password']; 
    $Confirm = $_POST['Confirm']; 
    $duplicate = mysqli_query($conn, "SELECT * FROM arigatu WHERE user = '$Username'");

    if($Password == $Confirm){


		if(mysqli_num_rows($duplicate) > 0 || is_numeric($Username)){
      echo "<script> alert('Username/Email Already Taken'); </script>";
		  }else{
    $query = "INSERT INTO arigatu (name, surname, user, pass) VALUES ('$Name','$Surname','$Username','$Password')";
    mysqli_query($conn, $query);
   echo "<script> alert('Successfully registered'); </script>";
          }
        }else{
          echo "<script> alert('Password Does Not Match'); </script>";
        }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="center">
        <h1>Registration</h1>
        <form method="post">
            <div class="txt_field">
                <input type="text" name="Name" required>
                <label>Name</label>
            </div>
            <div class="txt_field">
                <input type="text" name="Surname" required>
                <label>Surname</label>
            </div>
            <div class="txt_field">
                <input type="text" name="Username" required>
                <label>Username/Email</label>
            </div>
            <div class="txt_field">
                <input type="password" name="Password" required>
                <label>Password</label>
            </div>
            <div class="txt_field">
                <input type="password" name="Confirm" required>
                <label for="">Confirm Password</label>
            </div>
            <input type="submit" name="reg" value="Register">
            <div class="signup_link">
                Already have an account? <a href="login.php">Login</a>
            </div>
        </form>
    </div>
</body>
</html>

