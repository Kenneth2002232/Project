<?php 
include("connection.php");
if(!empty($_SESSION["id"])){
  $id = $_SESSION["id"];
}
else{
  header("Location: login.php");
}

$sel = "SELECT * FROM arigatu where id='$id'";
$query = mysqli_query($conn, $sel);
$result = mysqli_fetch_assoc($query);


if(isset($_POST['Edit'])){
   $name = $_POST['name'];
   $surn = $_POST['surname'];
   $user = $_POST['username'];
   $pass = $_POST['password'];
if($name && $surn && $user && $pass){
  $set = "UPDATE `arigatu` SET `user`='$user',`pass`='$pass',`name`='$name',`surname`='$surn' WHERE id='$id'";
  $qury = mysqli_query($conn, $set);

  echo "<script> alert('Update Succesfully'); </script>";
}else{
  echo "<script> alert('Please fill up all blank textbox'); </script>";
}
   
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="indexstyle.css">
  <link rel="stylesheet" href="bootstrap-5.3.0-dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="bootstrap-5.3.0-dist/bootstrap-icons-1.10.5/font/bootstrap-icons.min.css">
  <script src="bootstrap-5.3.0-dist/js/bootstrap.bundle.min.js"></script>
    <style>
        *{
          margin:0;
          padding:0;
          box-sizing:content-box;
        }
        .main{
          overflow:hidden;
          width:100%;
        }
        body{
          background-color:rgb(6, 6, 26);
        }
    form{
      margin-top:10%;
      background-color:white;
        border:2px solid black;
        margin-left:680px;
        width:25%;
        padding:20px 30px;
        text-align:center;
        border-radius:10px;
        position:absolute;
    }
    form .container{
      border:2px solid black;
      width:93%;
      display:flex;
    }
    form .container p{
      font-size:20px;
      text-align:center;
      border-radius:10px;
      min-height:40px;
      background-color: lightgray;
    }
    form .container label{
     font-size:20px;
     color:blue;
     margin-top:12px;
    }
    form .container ul li{
      list-style:none;
      text-align:center;
    }
    form .container .left {
      text-align:center;
      width:98%;
    }
    form .container .right {
      text-align:center;
      width:100%;
      margin-right:22px;
    }
    form .profile{
      margin:auto;
      border:1px solid black;
      min-height:20vh;
      text-align:center;
    }
    form .profile p{
    font-size:140px;
    }
    form button{
      margin: 3% auto;
      font-size:20px;
      text-decoration:none;
      padding:5px 30px;
    }
    .edit{
      min-height:44.5vh;
    margin-left:-1800px;
    }
    .edit input{
      width:60%;
      min-height:4vh;
    }
    .edit label{
      margin-top:20px;
    }
    .edit button{
     margin-top:20px;
     width:100px;
     border-radius:10px;
     min-height:30px;
    }

    </style>
</head>
<body>
 <div class="main">
<form id="view">
<div class="profile">
<p><i class="bi bi-person-circle"></i></p>
</div>
<a href="index.php"><button type="button">Exit</button></a>
<button type="button" onclick="edit()">Edit</button>
<div class="container">
     <ul class="left">
    <li><label>Name:</label>
    <p><?php echo $result['name']; ?></p><li>
    <li><label>Surname:</label>
    <p><?php echo $result['surname']; ?></p><li>
  </ul>

  
  <ul class="right">
  <li><label>Email/Username:</label>
  <p><?php echo $result['user']; ?></p></li>
  <li> <label>Password:</label>
   <p><?php echo $result['pass']; ?></p><li>
  <ul>
  </div>
</form>
<form action="userprofile.php" method="POST" class="edit" id="edit">
<label>Name:</label><br>
<input type="text" placeholder="Enter Username" name="name" ><br>
<label>Surname:</label><br>
<input type="text" placeholder="Enter Username" name="surname" ><br>
<label>Username:</label><br>
<input type="text" placeholder="Enter Username" name="username" ><br>
<label>Password:</label><br>
<input type="text" placeholder="Enter Username" name="password" ><br>
<button onclick="onlick()">CANCEL</button><button type="submit" name="Edit">UPDATE</button>
</form>
  </div>
  <script src="js/script.js"></script>
</body>
</html>