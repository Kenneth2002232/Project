  window.addEventListener("scroll", function(){
      var header = document.querySelector("header");
      header.classList.toggle("sticky", window.scrollY > 0 ); 
  })

  function bg2() {
    document.getElementById('home_content').style.backgroundImage="url(pics/wp3.jpg)"
    document.getElementById('bot2').style.backgroundColor="#dc3545"
    document.getElementById('bot').style.backgroundColor="transparent"
}
function bg1() {
    document.getElementById('home_content').style.backgroundImage="url(pics/wp1.jpg)"
    document.getElementById('bot2').style.backgroundColor="transparent"
    document.getElementById('bot').style.backgroundColor="#dc3545"
}
function wol() {
    document.getElementById('col1').style.marginTop="0"
    document.getElementById('wol').style.backgroundColor="white"
    document.getElementById('wol').style.color="black"

    document.getElementById('ss').style.backgroundColor="transparent"
    document.getElementById('ss').style.color="white"

    document.getElementById('rp').style.backgroundColor="transparent"
    document.getElementById('rp').style.color="white"

    document.getElementById('wr').style.backgroundColor="transparent"
    document.getElementById('wr').style.color="white"

}
function ss() {
    document.getElementById('col1').style.marginTop="-60.4%"
    document.getElementById('ss').style.backgroundColor="white"
    document.getElementById('ss').style.color="black"

    document.getElementById('wol').style.backgroundColor="transparent"
    document.getElementById('wol').style.color="white"

    document.getElementById('rp').style.backgroundColor="transparent"
    document.getElementById('rp').style.color="white"

    document.getElementById('wr').style.backgroundColor="transparent"
    document.getElementById('wr').style.color="white"
}
function rp() {
    document.getElementById('col1').style.marginTop="-121%"
    document.getElementById('rp').style.backgroundColor="white"
    document.getElementById('rp').style.color="black"

    document.getElementById('ss').style.backgroundColor="transparent"
    document.getElementById('ss').style.color="white"

    document.getElementById('wol').style.backgroundColor="transparent"
    document.getElementById('wol').style.color="white"

    document.getElementById('wr').style.backgroundColor="transparent"
    document.getElementById('wr').style.color="white"
}
function wr() {
    document.getElementById('col1').style.marginTop="-181.8%"
    document.getElementById('wr').style.backgroundColor="white"
    document.getElementById('wr').style.color="black"

    document.getElementById('ss').style.backgroundColor="transparent"
    document.getElementById('ss').style.color="white"

    document.getElementById('rp').style.backgroundColor="transparent"
    document.getElementById('rp').style.color="white"

    document.getElementById('wol').style.backgroundColor="transparent"
    document.getElementById('wol').style.color="white"
}
function edit() {
    document.getElementById('edit').style.marginLeft="680px"
    document.getElementById('view').style.marginLeft="-1800px"
}
function view() {
    document.getElementById('view').style.marginLeft="680px"
    document.getElementById('edit').style.marginLeft="-1800px"
}