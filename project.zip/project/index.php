<?php
include("connection.php");
if(!empty($_SESSION["id"])){
    $id = $_SESSION["id"];
  }
  else{
    header("Location: login.php");
  }
if(isset($_POST['Send'])){
   $name = $_POST['name'];
   $email = $_POST['email'];
   $contact = $_POST['contact'];
   $comment = $_POST['comment'];

   $query = "INSERT INTO comment_section (name, email, contact, comment) VALUES ('$name', '$email', '$contact', '$comment')";
   $result = mysqli_query($conn, $query);

   echo "<script> alert('Comment Succesfully'); </script>";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Bleach</title>
  <link rel="stylesheet" href="indexstyle.css">
  <link rel="stylesheet" href="bootstrap-5.3.0-dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="bootstrap-5.3.0-dist/bootstrap-icons-1.10.5/font/bootstrap-icons.min.css">
  <script src="bootstrap-5.3.0-dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
 <!-- header part -->
 <header>
  <nav class="container-fluid">
    <input type="checkbox" id="check">
    <label for="check" class="checkbtn">
      <i class="bi bi-list"></i>
      </label>
    <label><img src="pics/logo.png"></label>
    <ul>
      <li><a href="#Home">Home</a></li>
      <li><a href="#About">About</a></li>
      <li><a href="#Contact">Contact us</a></li>
      <li><a href="#character">Characters</a></li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false" id="dropdown"><i class="bi bi-person"></i></a>
        <ul class="dropdown-menu">
          <li><a class="dropdown-item" href="userprofile.php"><i class="bi bi-person"></i>Profile Settings</li>
          <li><a class="dropdown-item" href="#"><a href="login.php" class = "logout">Logout</a></a></li>
        </ul>
      </li>
    </ul>
  </nav> 
 </header>
<!-- Header ends here -->

<!-- home section -->

<div id="Home">
<section id="home_content">
<div class="inside_content">
    <br> <br> 
    <a id="bot" href="#"><button onclick="bg1()">1</button></a>
 <a id="bot2" href="#" ><button onclick="bg2()">2</button></a><br>

    <label>Action</label>
    <br>
 <h3>BLEACH: Thousand-Year Blood War</h3>
 <p>Substitute Soul Reaper Ichigo Kurosaki spends his days fighting against Hollows, dangerous evil spirits that threaten Karakura Town. Ichigo carries out his quest with his closest allies: Orihime Inoue, his childhood friend with a talent for healing; Yasutora Sado, his high school classmate with superhuman strength; and Uryuu Ishida, Ichigo's Quincy rival. Ichigo's vigilante routine is disrupted by the sudden appearance of Asguiaro Ebern, a dangerous Arrancar who heralds the return of Yhwach, an ancient Quincy king.</p>
 <a href="https://www.youtube.com/watch?v=Eh6a3Lg8ZlQ"><i class="bi bi-play">Watch Now </i></a>
 <a class="read" href="#About">Read More...</a><br> <br><br>
</div>
</section>
</div>
<!-- home section ends here -->

<div class="hr">
<hr class="wew">
</div>


<!-- about section starts here -->
<div id="About"> 
<div class="about_content">  
 <div class="image">
 </div>
 <div class="left_about">
  <br>
  <h3>BLEACH: THOUSAND-YEAR BLOOD WAR ARC </h3>
  <div class="fonts">
    <br>
  <label>Bleach: Thousand-Year Blood War Arc, Bleach: Sennen Kessen-hen, Bleach: Thousand-Year Blood War Arc, Bleach:<br> Sennen Kessen Hen, BLEACH 千年血戦篇</label>
  <br><br>
  <article>Substitute Soul Reaper Ichigo Kurosaki spends his days fighting against Hollows, dangerous evil spirits that <br>threaten Karakura Town. Ichigo carries out his quest with his closest allies: Orihime Inoue, his childhood friend <br>with a talent for healing; Yasutora Sado, his high school classmate with superhuman strength; and Uryuu Ishida,<br> Ichigo's Quincy rival. Ichigo's vigilante routine is disrupted by the sudden appearance of Asguiaro Ebern, a<br> dangerous Arrancar who heralds the return of Yhwach, an ancient Quincy king. Yhwach seeks to reignite the<br> historic blood feud between Soul Reaper and Quincy, and he sets his sights on erasing both the human world<br> and the Soul Society for good. Yhwach launches a two-pronged invasion into both the Soul Society and Hueco<br> Mundo, the home of Hollows and Arrancar. In retaliation, Ichigo and his friends must fight alongside old allies<br> and enemies alike to end Yhwach's campaign of carnage before the world itself comes to an end.</article>
<div class="sub_stats">
  <ul>
    <li>Type: TV Series</li>
    <li>Studios: Pierrot</li>
    <li>Date aired: Oct 10, 2022 to Dec 27, 2022</li>
    <li>Status: Finished Airing</li>
    <li>Genre: Action, Adventure, Comedy, Shounen, Super</li>
    <li>Power, Supernatural</li>
  </ul>
  <ul>
    <li>Scores: 0</li>
    <li>Premiered: Fall 2022</li>
    <li>Duration: 23 min/ep</li>
    <li>Quality: HD</li>
    <li>Status: On-Going</li>

  </ul>
  </div>
</div>
  </div>
 </div>
 </div>

<!-- about section ends here -->
<div class="hr" id="waw">
  <hr class="wew">
  </div>
  

  <!-- Contact Us section starts here -->
  <div id="Contact">
  <div class="contact_content" >
    <form class="contact_left" method="post" >
      <input type="text" name="name" placeholder="Your Name" required>
      <input type="text" name="email" placeholder="Your Email" required>
      <input type="text" name="contact" placeholder="Your Contact Number" required>
      <input type="text" name="comment" placeholder="Share Your thoughts" required><br>
      <button type="submit" name="Send">Send Your Thoughts</button>
    </form>
    <div class="contact_right">
      <h1>Connect With Us</h1>
      <span>it is very important for us to keep in touch with you so we are always ready to answer any question that interest you. Have a nice Day!</span>
      <ul>
        <li><i class="bi bi-telephone"> 0945683125469</i></li>
        <li><i class="bi bi-envelope"> jhonkenneth@gmail.com</i></li>
        <li><i class="bi bi-messenger"> messenger.com</i></li>
      </ul>
    </div>
  </div>
  </div>
  <!-- Contact us section end here -->

<div class="hr">
  <hr class="wew">
  </div>

<!-- Character section starts here -->
<div id="character">
  <img src="pics/logo.png" class="logo">
  <div id="map">
<button onclick="wol()" id="wol">World Of Living</button>
<button onclick="ss()" id="ss">Soul Society</button>
<button onclick="rp()" id="rp">Royal Place</button>
<button onclick="wr()" id="wr">WanderReich</button>
</div>

<div class="container text-center" id="col1">
  <div class="row align-items-start">
    <div class="col">
      <img src="pics/wol.png" class="img">
    </div>
    <div class="col">
      <img src="pics/inoue.png">
    </div>
    <div class="col">
      <img src="pics/uryu.png">
    </div>
  </div>
  <div class="row align-items-start">
    <div class="col">
      <img src="pics/sado.png">
    </div>
    <div class="col">
      <img src="pics/urahara.png">
    </div>
    <div class="col">
      <img src="pics/ishida.png">
    </div>
  </div>
</div>
<div class="container text-center" id="col2">
  <div class="row align-items-start">
    <div class="col">
      <img src="pics/yamamoto.png">
    </div>
    <div class="col">
      <img src="pics/aizen.png">
    </div>
    <div class="col">
      <img src="pics/shunsui.png">
    </div>
  </div>
  <div class="row align-items-start">
    <div class="col">
      <img src="pics/hitsu.png">
    </div>
    <div class="col">
      <img src="pics/shinji.png">
    </div>
    <div class="col">
      <img src="pics/ken.png">
    </div>
  </div>
</div>
<div class="container text-center" id="col3">
  <div class="row align-items-start">
    <div class="col">
      <img src="pics/hyosu.png">
    </div>
    <div class="col">
      <img src="pics/nimai.png">
    </div>
    <div class="col">
      <img src="pics/kirniji.png">
    </div>
  </div>
  <div class="row align-items-start">
    <div class="col">
      <img src="pics/shutara.png">
    </div>
    <div class="col">
      <img src="pics/hikifune.png">
    </div>
    <div class="col">
      <img src="pics/ken.png">
    </div>
  </div>
</div>
<div class="container text-center" id="col4">
  <div class="row align-items-start">
    <div class="col">
      <img src="pics/yhwach.png">
    </div>
    <div class="col">
      <img src="pics/hasch.png">
    </div>
    <div class="col">
      <img src="pics/loyd.png">
    </div>
  </div>
  <div class="row align-items-start">
    <div class="col">
      <img src="pics/bam.png">
    </div>
    <div class="col">
      <img src="pics/asn.png">
    </div>
    <div class="col">
      <img src="pics/bazz.png">
    </div>
  </div>
</div>

</div>
<!-- Character section ends here -->


<!-- footer starts here -->
 <footer>

  <div id="sns">
    <h1>Contact Us:</h1>
    <a href=""><i class="bi bi-facebook"></i></a>
    <a href=""><i class="bi bi-google"></i></a>
    <a href=""><i class="bi bi-instagram"></i></a>
    <a href=""><i class="bi bi-envelope"></i></a>
    <a href=""><i class="bi bi-twitter"></i></a>
  </div>
  <div class="footerNav">
  </div>
  <div class="footerBottom">
    <p>Copyright &copy; 2023; Made By: Group ni jowi</p>
  </div>



 </footer>
<!-- footer ends here -->


 <script src="js/script.js"></script>
</body>
</html>